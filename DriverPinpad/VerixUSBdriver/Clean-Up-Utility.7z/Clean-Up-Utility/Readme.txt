The "CleanUpUtility.bat" is provided to clean the previously installed VFI VX USB drivers and the driver residue present.

Steps:

Method1:
1. Login to PC as System administrator.
2. Copy the complete folder to any desired location.
3. Double click on the "CleanUpUtility.bat".


Method2:
1. Login to PC as user with user administrator prieveleges.
2. Copy the complete folder to any desired location.
3. Right click on the CleanUpUtility.bat.
4. click on the "Run as Administrator".


Note:
1. This has to be used prior to the installation of any new VFI VX USB drivers and after un-installation of any VFI USB driver.


